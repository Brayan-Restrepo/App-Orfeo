# Materialize Pagination

<p align="left">
  <img src="/../screenshots/screenshot_2.png?raw=true" height="110px" align="left">
</p>

Materialize Pagination is a jQuery plugin that provides behaviour and  rendering of the [Materialize Pagination component][1].

Compatible materialize v0.100 and jQuery 3. Answers the two open issues on the original repository.

Fork on the mirjamsk depot https://mirjamsk.github.io/materialize-pagination/
